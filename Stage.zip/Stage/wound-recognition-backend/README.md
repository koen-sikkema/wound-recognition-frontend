before starting the server please install requirements:

```pip install -r /path/to/requirements.txt``` 

pip install -r requirements.txt

To start the server use:
```python -m uvicorn app.main:app --reload```

``` uvicorn app.main:app --reload``` 

This will start the server on http://127.0.0.1:8000
Docs will be on http://127.0.0.1:8000/docs
