
from dotenv import load_dotenv
import os

# Laad de .env file

load_dotenv()

# Haal de database URL op uit de .env
DATABASE_URL = os.getenv("DATABASE_URL")

