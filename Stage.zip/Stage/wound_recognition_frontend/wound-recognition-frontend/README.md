# wound-recognition-frontend
This is a frontend for poc woundrecognition application for an internship at Health-Hub Roden
