package com.example.wound_recognition_frontend

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
