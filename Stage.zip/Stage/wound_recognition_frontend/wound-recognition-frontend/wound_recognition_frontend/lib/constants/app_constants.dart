
class AppConstants {
  static const String APPNAME = 'WondherkenningsApplicatie';
  static const String UPLOADURI = '/upload';
  static const String RESULTURI = '/result';
  static const String HOMEURI = '/';
  static const String SERVERURI = 'http://127.0.0.1:8000/upload/';
  static const String POST = 'post';
  static const String GET = 'get';
}