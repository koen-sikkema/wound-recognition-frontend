
class AppStrings{
  static const String uploadImageText = 'Upload hier uw wondafbeelding';
  static const String uploadPage = 'Upload Pagina';
  static const String resultPage = 'Result Pagina';
  static const String homePage = 'Home Pagina';
  static const String uploadButtonText = 'Afbeelding Uploaden';
}