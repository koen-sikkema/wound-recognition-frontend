
import 'package:wound_recognition_frontend/services/upload_service/uploader.dart';
import 'package:wound_recognition_frontend/services/upload_service/Iuploader.dart';

Iuploader getUploader(){
  return Uploader();
}

