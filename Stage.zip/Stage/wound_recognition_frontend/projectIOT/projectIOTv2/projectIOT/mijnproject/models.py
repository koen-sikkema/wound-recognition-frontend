from sqlalchemy import ForeignKey, over
from mijnproject import db, login_manager
from flask_login import UserMixin
from werkzeug.security import generate_password_hash,check_password_hash

class Medicijn(db.Model):
    __tablename__ = 'medicijn'
    
    # Primary Key column, uniek voor iedere klant als int
    id = db.Column(db.Integer, primary_key=True)
    # Dit is de id van de klant die de reservering geplaatst heeft. Dit staat in relatie met de kolom id van de tabel klant
    klant_id = db.Column(db.Integer, db.ForeignKey('klant.id'), nullable=False)
    # Het bakje waar het medicijn in gaat
    bakje_nr = db.Column(db.Integer, db.ForeignKey('bakje.nr'), unique = True, nullable = False)
    # medicijn naam
    naam = db.Column(db.String(75), nullable = False)
    # Hoeveel van het medicijn
    aantal_medicijn = db.Column(db.Integer, nullable = False)
    # hoeveel maal per dag moet het medicijn ingenomen worden
    maal_per_dag = db.Column(db.Integer, nullable = False)
    # tijd van medicijn uitgave 
    tijd_van_uitgave = db.Column(db.Time, nullable = False)
    # nuchter voor het innemen van het medicijn
    nuchter = db.Column(db.Boolean, nullable = False)
    # extra herinnering voor inname medicijn #nice2have
    herinnering = db.Column(db.Boolean, nullable = True)

    def __init__(self, bakje_nr, naam, aantal_medicijn, maal_per_dag, nuchter, tijd_van_uitgave, herinnering):
        
        self.bakje_nr = bakje_nr
        self.naam = naam
        self.aantal_medicijn = aantal_medicijn
        self.maal_per_dag = maal_per_dag
        self.tijd_van_uitgave = tijd_van_uitgave
        self.nuchter = nuchter
        self.herinnering = herinnering
        
    def __repr__(self): 
        return f"{self.naam}"

class Bakje(db.Model):
    __tablename__ = "bakje"
    
    # Het bakje waar het medicijn in gaat
    nr = db.Column(db.Integer, primary_key=True)
    # Het bakje waar het medicijn in gaat
    bakje_nr = db.Column(db.Integer, unique = True, nullable = False)
    # de relatie naar het medicijn
    medicijn = db.relationship("Medicijn", backref="Bakje", lazy="dynamic")

    def __init__(self, bakje_nr):

        self.bakje_nr = bakje_nr

    def __repr__(self):
        return f"{self.bakje_nr}"

class Klant(db.Model, UserMixin):
    __tablename__ = 'klant'

    # Primary Key column, uniek voor iedere klant als int
    id = db.Column(db.Integer, primary_key=True)
    # Voornaam en achternaam van de klant als string
    voornaam = db.Column(db.String(50), nullable = False)
    achternaam = db.Column(db.String(75), nullable = False)
    # Username van de klant als string
    username = db.Column(db.String(20), nullable = False, unique = True)
    # De hash van het wachtwoord
    password_hash = db.Column(db.String(100), nullable = False)
    # De reserveringen van de klant, dit wordt afgeleid van de tabel reservering
    medicijn = db.relationship("Medicijn", backref="klant", lazy="dynamic")
    # Een boolean die bepaalt of de gebruiker een administrator is
    is_admin = db.Column(db.Boolean, default=False)

    # Hier wordt aangegeven wat iedere instantie meekrijgt aan het begin
    def __init__(self, voornaam, achternaam, email, username, password, telefoon_nr, admin):
        self.voornaam = voornaam
        self.achternaam = achternaam
        self.email = email
        self.username = username
        self.password_hash = generate_password_hash(password)
        self.telefoon_nr = telefoon_nr
        self.is_admin = admin

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        # Deze tekst wordt getoond als een klant wordt aangeroepen
        return f"{self.username}"

@login_manager.user_loader
def load_user(klant_id):
    return Klant.query.get(klant_id)