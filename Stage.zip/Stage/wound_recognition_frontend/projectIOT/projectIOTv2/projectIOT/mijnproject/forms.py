from xmlrpc.client import Boolean
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, PasswordField, IntegerField, SelectField, BooleanField, TimeField
from wtforms.validators import data_required, Email, EqualTo, Length, NumberRange
from wtforms.fields import EmailField
from wtforms import ValidationError
from mijnproject.models import Medicijn, Bakje, Klant
#$from wtforms_sqlalchemy.fields import QuerySelectField
from flask import flash
from flask_sqlalchemy import SQLAlchemy





# Login formulier
class MedicijnForm(FlaskForm):

    # nr = IntegerField('Kies het bakje: ', validators=[data_required()])
    bakje_nr = IntegerField('Bakje nr: ', validators=[NumberRange(min=1, max=8, message='Kies een bakje'), data_required()])
    naam = StringField('Naam van uw medicijn: ', validators=[data_required()])
    aantal_medicijn = IntegerField("Hoeveel van dit medicijn heeft u:", validators=[data_required()])
    maal_per_dag = IntegerField("Aantal innames per dag:" ,validators=[data_required()])
    tijd_van_uitgave = TimeField("Tijd van uitgave:" ,validators=[data_required()])
    nuchter = BooleanField("Neemt u het medicijn nuchter?")
    herinnering = BooleanField("Extra herinnering? (n2h)")
    submit = SubmitField('Voeg medicijn toe!')

class Delete_medicijn_form(FlaskForm):
    bakje_nr = IntegerField('Bakje nr: ', validators=[NumberRange(min=1, max=8, message='Kies een bakje'), data_required()])
    submit = SubmitField('Verwijderen medicijn!')

class LoginForm(FlaskForm):
    username  = StringField('Gebruikersnaam: ', validators=[data_required()])
    password = PasswordField('Wachtwoord: ', validators=[data_required()])
    submit = SubmitField('Log in')

class SignupForm(FlaskForm):
    voornaam = StringField('Voornaam: ', validators=[data_required()])
    achternaam = StringField("Achternaam: ", validators=[data_required()])
    submit = SubmitField('Account aanmaken')
    username  = StringField('Gebruikersnaam: ', validators=[data_required()])
    password = PasswordField('Wachtwoord: ', validators=[data_required(), EqualTo('pass_confirm',    message='Ingevoerde wachtwoorden zijn niet gelijk!'), Length(min=6, message='Uw wachtwoord moet minimaal 6 karakters lang zijn.')])
    pass_confirm = PasswordField('Herhaal wachtwoord', validators=[data_required()])
    submit = SubmitField('Leg vast!')

    def validate_email(self, email):
        if Klant.query.filter_by(email=email.data).first():
            flash("Dit e-mailadres staat al geregistreerd!")
            raise ValidationError

    def validate_username(self, username):
        if Klant.query.filter_by(username=username.data).first():
            flash('Deze gebruikersnaam is al in gebruik!')
            raise ValidationError