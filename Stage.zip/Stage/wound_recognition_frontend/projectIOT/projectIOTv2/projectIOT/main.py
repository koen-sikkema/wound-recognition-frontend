from boot import connection
from machine import Pin, ADC
import config
import urequests as requests
import json
from time import sleep

ledblauw = Pin(2, Pin.OUT)
ledrood = Pin(32, Pin.OUT)
url = f"http://{config.SERVER}:{config.PORT}{config.ENDPOINT}"

while connection.isconnected():
    # read temperature
    tmp36 = Pin(34, Pin.IN)
    adc = ADC(tmp36)
    prop = 1100 / 65535
    v_out = adc.read_u16() * prop
    temp = (v_out - 500) / 10

    # send temperature to server    
    print(temp)
    data = temp
    encoded = json.dumps(data)
    response = requests.post(url, json=encoded)
    # flash blue LED indicating temperature was sent
    if response.json():
        for _ in range(2):
            ledblauw.on()
            sleep(0.5)
            ledblauw.off()
            sleep(0.5)
    # read server response
    answer = response.json()
    decoded = json.loads(answer)
    # set or unset red LED if server tells us to do so
    if decoded["warning"] == "warm":
        ledrood.on()
    else:
        ledrood.off()
    # sleep a little until next temperature reading
    sleep(2)