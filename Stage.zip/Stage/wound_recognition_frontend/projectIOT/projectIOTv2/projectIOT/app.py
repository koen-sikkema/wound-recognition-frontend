from sqlalchemy import literal
from mijnproject import app, db, admin
from flask import Flask, render_template, redirect, request, url_for, flash, abort, jsonify
from mijnproject.models import Medicijn , Bakje, Klant
from flask_login import login_user, login_required, logout_user, current_user
from mijnproject.forms import LoginForm, MedicijnForm, SignupForm, Delete_medicijn_form
from flask_admin.contrib.sqla import ModelView
import json



# Hallo jongens

# Creeërt/update de database
db.create_all()

# ESP dingen
@app.route("/temperature", methods=["POST"])
def temperature():
    """An endpoint accepting a temperature reading"""

    data = request.json  # temperature reading
    decoded = json.loads(data)
    
    if decoded >= 28:
        data = { 
            "warning": "warm"
        }
        encoded = json.dumps(data)
        return jsonify(encoded)
    else: 
        data = {
            "warning": "koud"
        }
        encoded = json.dumps(data)
        return jsonify(encoded)
# einde ESP dingen


class Controller(ModelView):
    def is_accessible(self):
        if current_user.is_authenticated:
            if  current_user.is_admin == True:
                return current_user.is_authenticated
            else: return abort(404)
        else:
            return abort(404)
    def not_auth(self):
        return "access denied"

admin.add_view(Controller(Klant, db.session))
admin.add_view(Controller(Medicijn, db.session))
admin.add_view(Controller(Bakje, db.session))

admin_check = Klant.query.filter_by(username='admin').count()
if admin_check < 1:
    admin = Klant(voornaam='admin', achternaam='admin', username='admin', password='admin', admin=True)
    db.session.add(admin)
    db.session.commit()

# Route voor de Index(home) pagina
@app.route("/", methods=['GET', 'POST'])       
def add_medicijn():
    
    form = MedicijnForm()
    if current_user.is_authenticated:
        if request.method == 'POST':
            if form.validate_on_submit():
                medicijn = Medicijn(bakje_nr=form.bakje_nr.data,
                                    naam=form.naam.data,
                                    aantal_medicijn=form.aantal_medicijn.data,
                                    maal_per_dag=form.maal_per_dag.data, 
                                    tijd_van_uitgave=form.tijd_van_uitgave.data, 
                                    nuchter=form.nuchter.data, 
                                    herinnering=form.herinnering.data
                                    )

               

                       
                db.session.add(medicijn)
                db.session.commit()
                flash('U heeft een medicijn toegevoegd')
                return redirect(url_for('view'))

    else:
        return redirect(url_for('login'))
    return render_template("base.html", form=form)


@app.route("/delete_medicijn", methods=["GET", "POST"])
@login_required
def Delete_medicijn():
    form = Delete_medicijn_form()
    if form.validate_on_submit():
        id = form.bakje_nr.data
        medicijn = Medicijn.query.get(id)

        db.session.delete(medicijn)
        db.session.commit()

        flash('U heeft een medicijn verwijderd!')
        return redirect(url_for('view'))

    return render_template("delete_medicijn.html", form=form)


@app.route("/view", methods=['GET', 'POST'])
def view():
    
    medicijn = Medicijn.query.all()
    

    return render_template("view.html", medicijn=medicijn)

@app.route("/signup", methods=["GET", "POST"])
def signup():
    form=SignupForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            user = Klant(username=form.username.data,
            password=form.password.data,
            voornaam=form.voornaam.data,
            achternaam=form.achternaam.data,
            admin=False
            )

            db.session.add(user)
            db.session.commit()
            flash('Account aangemaakt!')
            next = request.args.get('next')
            if next == None or not next[0]=='/':
                next = url_for('login')
                return redirect(next)
    return render_template("signup.html", form=form)

@app.route("/login", methods=['GET', 'POST'])
def login():
    form=LoginForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            user = Klant.query.filter_by(username=form.username.data).first()
            if user is not None:
                if user.check_password(form.password.data):
                    login_user(user)
                    flash('U bent succesvol ingelogd!')
                    return redirect(url_for('add_medicijn'))
                else:
                    flash('De gegevens die u heeft ingevoerd zijn onjuist')
                    return redirect(url_for('login'))
            else:
                flash('De gegevens die u heeft ingevoerd zijn onjuist')
                return redirect(url_for('login'))
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('U bent nu uitgelogd!')
    return redirect(url_for('add_medicijn'))

# added, voor ESP
# host="0.0.0.0", port=5000,

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug = True)
    db.create_all()