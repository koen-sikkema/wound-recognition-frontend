from xmlrpc.client import Boolean
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, PasswordField, IntegerField, SelectField, BooleanField
from wtforms.validators import data_required, Email, EqualTo, Length, NumberRange
from wtforms.fields import EmailField
from wtforms import ValidationError
from mijnproject.models import Medicijn, Bakje, klant
from wtforms_sqlalchemy.fields import QuerySelectField
from flask import flash
from flask_sqlalchemy import SQLAlchemy


def BakjeKeuze():
    return Bakje.query

# Login formulier

class MedicijnForm(FlaskForm):

    # nr = IntegerField('Kies het bakje: ', validators=[data_required()])
    bakje_nr = QuerySelectField(query_factory=BakjeKeuze, allow_blank=False)
    naam = StringField('Naam van uw medicijn: ', validators=[data_required()])
    aantal_medicijn = IntegerField("Hoeveel van dit medicijn heeft u:", validators=[data_required()])
    maal_per_dag = IntegerField("Aantal innames per dag:" ,validators=[data_required()])
    tijd_van_uitgave = IntegerField("Tijd van uitgave:" ,validators=[data_required()])
    nuchter = StringField("Neemt u het medicijn nuchter?" ,validators=[data_required()])
    herinnering = StringField("Extra herinnering? (n2h)", validators=[data_required()])
    submit = SubmitField('Voeg medicijn toe!')

class LoginForm(FlaskForm):
    username  = StringField('gebruikersnaam: ', validators=[data_required()])
    password = PasswordField('wachtwoord: ', validators=[data_required()])
    submit = SubmitField('log in')

class SignupForm(FlaskForm):
    voornaam = StringField('Voornaam: ', validators=[data_required()])
    achternaam = StringField("Achternaam: ", validators=[data_required()])
    email = EmailField('emailadres: ', validators=[data_required()])
    telefoon_nr = StringField('Telefoonnummer*: ')
    submit = SubmitField('account aanmaken')
    username  = StringField('gebruikersnaam: ', validators=[data_required()])
    password = PasswordField('wachtwoord: ', validators=[data_required(), EqualTo('pass_confirm',    message='Ingevoerde wachtwoorden zijn niet gelijk!'), Length(min=6, message='Uw wachtwoord moet minimaal 6 karakters lang zijn.')])
    pass_confirm = PasswordField('Herhaal wachtwoord', validators=[data_required()])
    submit = SubmitField('Leg vast!')

    def validate_email(self, email):
        if klant.query.filter_by(email=email.data).first():
            flash("Dit e-mailadres staat al geregistreerd!")
            raise ValidationError

    def validate_username(self, username):
        if klant.query.filter_by(username=username.data).first():
            flash('Deze gebruikersnaam is al in gebruik!')
            raise ValidationError