
class AppStrings{
  static const String uploadImage = 'Upload hier uw wondafbeelding';
  static const String uploadPage = 'Upload een Wondafbeelding';
  static const String resultPage = 'Resultaat Pagina';
  static const String homePage = 'Home Pagina';
  static const String uploadButton = 'Afbeelding Uploaden';
  static const String appName = 'WondherkenningsApp';
  static const String chooseImage = 'Selecteren uit Galerij';
  static const String predictionsPage = 'Lokale Voorspellingen';
  static const String historyPage = 'Geschiedenis Ophalen';
}